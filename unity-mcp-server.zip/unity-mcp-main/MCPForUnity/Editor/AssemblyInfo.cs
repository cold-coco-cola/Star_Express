using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("MCPForUnityTests.EditMode")]
