"""Unity MCP Command Line Interface."""

__version__ = "1.0.0"
