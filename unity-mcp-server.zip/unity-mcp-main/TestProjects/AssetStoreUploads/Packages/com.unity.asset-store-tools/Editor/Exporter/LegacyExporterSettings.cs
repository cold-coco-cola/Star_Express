namespace AssetStoreTools.Exporter
{
    internal class LegacyExporterSettings : PackageExporterSettings
    {
        public string[] ExportPaths;
        public bool IncludeDependencies;
    }
}