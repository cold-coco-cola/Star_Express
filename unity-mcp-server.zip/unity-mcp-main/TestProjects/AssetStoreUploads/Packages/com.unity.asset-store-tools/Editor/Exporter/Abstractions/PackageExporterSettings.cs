﻿namespace AssetStoreTools.Exporter
{
    internal abstract class PackageExporterSettings
    {
        public string OutputFilename;
    }
}