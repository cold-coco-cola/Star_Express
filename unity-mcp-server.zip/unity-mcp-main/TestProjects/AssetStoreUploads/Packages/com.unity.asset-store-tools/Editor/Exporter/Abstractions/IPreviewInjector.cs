﻿namespace AssetStoreTools.Exporter
{
    internal interface IPreviewInjector
    {
        void Inject(string temporaryPackagePath);
    }
}