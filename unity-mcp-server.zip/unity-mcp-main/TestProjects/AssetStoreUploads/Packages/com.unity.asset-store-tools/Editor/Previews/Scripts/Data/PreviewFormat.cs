namespace AssetStoreTools.Previews.Data
{
    internal enum PreviewFormat
    {
        JPG = 0,
        PNG = 1
    }
}