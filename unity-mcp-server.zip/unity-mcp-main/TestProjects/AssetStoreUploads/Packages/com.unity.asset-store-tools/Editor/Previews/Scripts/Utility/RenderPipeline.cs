namespace AssetStoreTools.Previews.Utility
{
    internal enum RenderPipeline
    {
        Unknown = 0,
        BiRP = 1,
        URP = 2,
        HDRP = 3
    }
}