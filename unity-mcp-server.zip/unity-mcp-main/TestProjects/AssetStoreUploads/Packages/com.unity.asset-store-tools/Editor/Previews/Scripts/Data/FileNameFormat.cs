namespace AssetStoreTools.Previews.Data
{
    internal enum FileNameFormat
    {
        Guid = 0,
        FullAssetPath = 1,
        AssetName = 2,
    }
}