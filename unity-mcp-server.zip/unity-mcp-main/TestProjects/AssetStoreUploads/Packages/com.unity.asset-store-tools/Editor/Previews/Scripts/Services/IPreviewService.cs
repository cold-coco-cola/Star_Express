namespace AssetStoreTools.Previews.Services
{
    public interface IPreviewService { }
}