using AssetStoreTools.Previews.Generators.Custom.Screenshotters;

namespace AssetStoreTools.Previews.Generators.Custom.TypeGenerators
{
    internal class TypePreviewGeneratorFromSceneSettings : TypeGeneratorSettings
    {
        public ISceneScreenshotter Screenshotter;
    }
}