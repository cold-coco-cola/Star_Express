namespace AssetStoreTools.Previews.Data
{
    internal enum GenerationType
    {
        Unknown = 0,
        Native = 1,
        Custom = 2
    }
}