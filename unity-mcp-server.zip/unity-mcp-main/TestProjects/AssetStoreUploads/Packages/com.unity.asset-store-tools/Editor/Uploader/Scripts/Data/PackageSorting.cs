namespace AssetStoreTools.Uploader.Data
{
    internal enum PackageSorting
    {
        Name,
        Category,
        Date
    }
}