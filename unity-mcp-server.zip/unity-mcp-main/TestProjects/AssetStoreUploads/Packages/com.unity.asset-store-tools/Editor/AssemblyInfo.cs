using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("AssetStoreTools.Tests")]
[assembly: InternalsVisibleTo("DynamicProxyGenAssembly2")]
[assembly: InternalsVisibleTo("ab-builder")]
[assembly: InternalsVisibleTo("Inspector-Editor")]
