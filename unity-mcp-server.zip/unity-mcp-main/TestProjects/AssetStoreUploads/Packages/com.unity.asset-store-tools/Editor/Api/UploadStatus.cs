namespace AssetStoreTools.Api
{
    internal enum UploadStatus
    {
        Default = 0,
        Success = 1,
        Fail = 2,
        Cancelled = 3,
        ResponseTimeout = 4
    }
}